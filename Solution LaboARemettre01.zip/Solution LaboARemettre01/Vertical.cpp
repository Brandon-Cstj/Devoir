// But : cr�er un programme qui support les chiffre de 5 nombre uniquement et les d�compose verticalement
// Auteur : Brandon Cordeiro-Ouimet
// Date : 2020-09-14

#include <iostream>


void main()
{

    setlocale(LC_ALL, "");

    int nombre1;

    std::cout << "Veuillez entrer un nombre entier contenant 5 chiffre : "; // Le programme invite l'utilisateur a rentrer un num�ro

    std::cin >> nombre1; // Le programme va lire les informations tap�e au clavier

    if (nombre1 >= 10000 <= 99999 ) // pour �tre s�r qu'il n'y est pas trop de chiffre 
                                    // ps : ne marche pas car je narrive pas a faire en sorte que se soit un intervalle,
                                    // en se moment il garde aucun des reponses et dit qu'il s'agit toujours du else
    {
        std::cout << nombre1 << " contient 5 chiffre ";
    }

    else  // pour dire que s'il ne fait pas parti de la condition du if, cela veut dire qu'il contient plus que 5 chiffres
    {
        std::cout << nombre1 << " Le nombre ne contient pas 5 chiffres ";
    }


    // J'ai mes doutes pour decomposer le chiffre sur une colone de 5 chiffres, mais je n'arrive pas a trouver les bons outils pour le faire
    // selon moi il faut utiliser des retour sur la ligne ainsi que disoler toute les chiffre avec des calcul 1 a la fois, mais je ne sais pas comment le faire


    return 0;

}