// but :
// auteur : 
// Date : 2020-09-14

#include <iostream>

int main()
{
	setlocale(LC_ALL, "");  // pour convertir correctement les accents

	int nombre1;

	std::cout << "Veuillez entrer un nombre entier : "; // Le programme invite l'utilisateur a rentrer un num�ro

	std::cin >> nombre1;  // Le programme va lire les informations tap�e au clavier



	if (nombre1 % 2 == 0) // pour savoir si le nombre est paire
	{
		std::cout << nombre1 << " Le nombre est pair ";
	}

	else  // si le nombre n'est pas	 pair, il va �tre impair
	{
		std::cout << nombre1 << " Le nombre est impair ";
	}


  /* Plan de test :
      1. 5 = est impair
	  2. 12 = est pair
	  3. 17 = est impair
	  4. 22 = est pair
	  5. 33 = est impair
  */

	return 0;
}