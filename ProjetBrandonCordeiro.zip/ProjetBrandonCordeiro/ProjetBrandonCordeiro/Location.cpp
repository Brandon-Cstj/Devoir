// but :�crire un programme pour calculer le montant qu�un individu devra d�bourser pour faire un voyage dans une automobile lou�e
// auteur : Brandon
// date : 2020-09-17

#include <iostream>
#include <iomanip>


int main()
{
	setlocale(LC_ALL, "");

	int nombre1;  // Represente les jours
	int nombre2;  // Represente les kilometres
	int resultat; // resultat de km/j
	int gaz; // consommation L/100Km
	int GazTotal; // consommation L/Km
	int PrixGaz; // prix du gaz par littre
	int limitkm; // limit de km par jour
	int CoutKmExtra; // Cout quand les KM depasse le nombre maximum de km par jour
	int TotalSansExtra; // le nombre d'argent total a depenser si on ne depasse pas 250 km
	int TotalAvecExtra; // le nombre d'argent total a depenser si on depasse 250 km
	
		std::cout << "Veuillez indiquer le nombre de jour que vous louer l'automobile : ";
		std::cin >> nombre1;
		std::cout << "Veuillez indiquer le nombre de km fait au total : ";
		std::cin >> nombre2;



		resultat = (nombre2 / nombre1);    // nombre de km par jour

		gaz = (7.6);                     // il consumme 0,076 L/Km ( les chiffres apres la virgules ne veulent pas rester et je ne sais pas comment arranger cela,
		                                 // jai essayer de jouer avec des chiffre different et de divisier mon nombre2 a la porchaine ligne par 1000 et de mettre 76 a la place,
		                                 // mais il m'afficher que le resultat et de 0

		GazTotal = (gaz * (nombre2/100)); // Littre total, au debut on avait le chiffre 7.6L pour 100Km, donc on divise par 100 pour avoir un prix pour chaque Km

		limitkm = (250*nombre1);           // Limit de km par jour sans payer en extra, 250 represente le nombre maximale de km disponible par jour sans payer des frais d'extra

		CoutKmExtra = ((nombre2 - limitkm) * 0,05); // encore une fois, ne marche pas car je ne sais pas comment garder les chiffres apres la virgules

		PrixGaz = (1.25 * GazTotal); // Prix du gaz, 1.25 represente le cout du gaz par littre

		TotalSansExtra = ((nombre1 * 45) + (PrixGaz)); // represente l'argent a payer si on ne depasse pas 250km/j

		TotalAvecExtra = ((nombre1 * 45) + (PrixGaz) + (CoutKmExtra)); // represente l'argent a payer si on depasse 250km/j
		


		if (resultat <= 250)            // nombre max de km par jours, donc le premier programme calcule si tu depasse les 250km par jours
		{
			std::cout << TotalSansExtra << " Repr�sente l'argent requis ";
		}

		else
		{
			std::cout << TotalAvecExtra << " Repr�sente l'argent requis ";
		}

		// Mes resultat ne marche pas, je pense que c'est a cause de les chiffres apres la virgules que le programme ne prend pas en compte 
		// J'ai essayer plusieurs chose different pour ne pas avoir de chiffres apres la virgules car je ne sais pas comment les faires lire au programme,
		// mais rien n'a marcher





	return 0; 

}